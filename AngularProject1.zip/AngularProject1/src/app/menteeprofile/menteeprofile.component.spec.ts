import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MenteeprofileComponent } from './menteeprofile.component';

describe('MenteeprofileComponent', () => {
  let component: MenteeprofileComponent;
  let fixture: ComponentFixture<MenteeprofileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MenteeprofileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MenteeprofileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
