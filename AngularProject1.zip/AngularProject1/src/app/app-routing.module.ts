import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomepageComponent } from './homepage/homepage.component';
import { MentorprofileComponent } from './mentorprofile/mentorprofile.component';
import { MentorlistComponent } from './mentorlist/mentorlist.component';
import { MentorviewComponent } from './mentorview/mentorview.component';
import { MenteeprofileComponent } from './menteeprofile/menteeprofile.component';
import { AdminprofileComponent } from './adminprofile/adminprofile.component';
import { PaymentComponent } from './payment/payment.component';
import { MentorsigninComponent } from './mentorsignin/mentorsignin.component';
import { MenteesigninComponent } from './menteesignin/menteesignin.component';
import { AdminsiginComponent } from './adminsigin/adminsigin.component';
import { BlockUnblockComponent } from './block-unblock/block-unblock.component';
import { UserblockComponent } from './userblock/userblock.component';
import { UnblockComponent } from './unblock/unblock.component';
import { UserunblockComponent } from './userunblock/userunblock.component'
import { AddrremovetechnologyComponent } from './addrremovetechnology/addrremovetechnology.component';
import { NewtechnologyComponent } from './newtechnology/newtechnology.component';



const routes: Routes = [
  { path: '', redirectTo: '/homepage', pathMatch: 'full' },
  { path: 'homepage', component: HomepageComponent  },
  { path: 'mentorprofile', component: MentorprofileComponent  },
  { path: 'mentorlist', component: MentorlistComponent  },
  { path: 'mentorview', component: MentorviewComponent  },
  { path: 'menteeprofile', component: MenteeprofileComponent  },
  { path: 'adminprofile', component: AdminprofileComponent  },
  { path: 'payment', component: PaymentComponent },
  { path: 'mentorsignin', component:MentorsigninComponent  },
  { path: 'menteesigin', component:MenteesigninComponent },
  { path: 'adminsigin', component:AdminsiginComponent },
  {path:'blockunblock', component:BlockUnblockComponent},
  {path:'userblock', component:UserblockComponent},
  {path:'unblock', component:UnblockComponent},
  {path:'userunblock', component:UserunblockComponent},
  {path:'addremovetechnology', component:AddrremovetechnologyComponent},
  {path:'newtechnology', component:NewtechnologyComponent}






];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
