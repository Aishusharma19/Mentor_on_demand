import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FooterComponent } from './footer/footer.component';
import { HomepageComponent } from './homepage/homepage.component';

import { MentorlistComponent } from './mentorlist/mentorlist.component';
import { MentorprofileComponent } from './mentorprofile/mentorprofile.component';
import { MentorviewComponent } from './mentorview/mentorview.component';
import { MenteeprofileComponent } from './menteeprofile/menteeprofile.component';
import { AdminprofileComponent } from './adminprofile/adminprofile.component';
import { PaymentComponent } from './payment/payment.component';
import { MentorsigninComponent } from './mentorsignin/mentorsignin.component';
import { MenteesigninComponent } from './menteesignin/menteesignin.component';
import { AdminsiginComponent } from './adminsigin/adminsigin.component';
import { BlockUnblockComponent } from './block-unblock/block-unblock.component';
import { UserblockComponent } from './userblock/userblock.component';
import { UnblockComponent } from './unblock/unblock.component';
import { UserunblockComponent } from './userunblock/userunblock.component';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { AddrremovetechnologyComponent } from './addrremovetechnology/addrremovetechnology.component';
import { NewtechnologyComponent } from './newtechnology/newtechnology.component';


@NgModule({
  declarations: [
    AppComponent,
    FooterComponent,
    HomepageComponent,
    
   
    MentorlistComponent,
    
   
    MentorprofileComponent,
    
   
    MentorviewComponent,
    
   
    MenteeprofileComponent,
    
   
    AdminprofileComponent,
    
   
    PaymentComponent,
    
   
    MentorsigninComponent,
    
   
    MenteesigninComponent,
    
   
    AdminsiginComponent,
    
   
    BlockUnblockComponent,
    
   
    UserblockComponent,
    
   
    UnblockComponent,
    
   
    UserunblockComponent,
    
   
    AddrremovetechnologyComponent,
    
   
    NewtechnologyComponent,

    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
