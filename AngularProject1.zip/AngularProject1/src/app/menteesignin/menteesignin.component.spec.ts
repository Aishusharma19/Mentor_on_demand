import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MenteesigninComponent } from './menteesignin.component';

describe('MenteesigninComponent', () => {
  let component: MenteesigninComponent;
  let fixture: ComponentFixture<MenteesigninComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MenteesigninComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MenteesigninComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
