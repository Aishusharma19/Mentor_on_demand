import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { UserSignupServiceService } from '../shared/user-signup-service.service';
import { UserSignup } from '../shared/user-signup';

@Component({
  selector: 'app-menteesignin',
  templateUrl: './menteesignin.component.html',
  styleUrls: ['./menteesignin.component.css']
})
export class MenteesigninComponent implements OnInit {

  userSignupform:FormGroup;
  userSigninform:FormGroup;

  submitted=false;


  constructor(private route:ActivatedRoute,private router:Router,private userService:UserSignupServiceService,private formBuilder:FormBuilder) { }
  usersignup:UserSignup=new UserSignup();
  ngOnInit() {
    this.userSignupform=this.formBuilder.group(
      {
        formFirstname:['',Validators.required],
        formlastname:['',Validators.required],
        formemail:['',Validators.required],
        formpassword:['',Validators.required],
      } );
      
      this.userSigninform=this.formBuilder.group(
        {
          formusername:['',Validators.required],
          formpassword:['',Validators.required],
         
        });
   

  }
  get f(){return this.userSignupform.controls;}
  onSubmit1(){
    this.submitted=true;
    this.usersignup.firstname=this.userSignupform.get('formFirstname').value;
    this.usersignup.lastname=this.userSignupform.get('formlastname').value;
    this.usersignup.email=this.userSignupform.get('formemail').value;
    this.usersignup.password=this.userSignupform.get('formpassword').value;
    this.userService.createUser(this.usersignup).subscribe(data=>console.log(data),error=>console.log(error));
    this.userService.userLogin(this.userSignupform.get("username").value).subscribe(data=>console.log(data),error=>console.log(error));
    
    
  }
  onSubmit2(){
    this.userService.userLogin(this.userSigninform.get("formusername").value).subscribe(
      data =>{
        this.usersignup=data;
      if(this.userSigninform.get("formpassword").value==this.usersignup.password){
          console.log("Success");
          this.router.navigateByUrl("/menteeprofile");
        }
        else{
          console.log("Fail");
        }
       
      });

    

  }

}
