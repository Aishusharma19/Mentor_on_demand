import { Component, OnInit } from '@angular/core';
import {LoginDetails} from '../shared/login-details';
import {AdminService} from '../shared/admin.service';
import {FormGroup,FormBuilder, Validators} from '@angular/forms';
import { Router } from '@angular/router';


@Component({
  selector: 'app-adminsigin',
  templateUrl: './adminsigin.component.html',
  styleUrls: ['./adminsigin.component.css'],
  providers:[AdminService]
})
export class AdminsiginComponent implements OnInit {
loginDetails:LoginDetails=new LoginDetails();
adminLoginForm:FormGroup;

  constructor(private adminService:AdminService,private fb:FormBuilder,private router:Router) {
   }

  ngOnInit() {

    this.adminLoginForm=this.fb.group({
      username:['',Validators.required],
      password:['',Validators.required],
    });
  }

  onSubmit(){
    this.adminService.adminLogin(this.adminLoginForm.get("username").value).subscribe(
      data =>{
        this.loginDetails=data;
      if(this.adminLoginForm.get("password").value==this.loginDetails.password){
          console.log("Success");
          this.router.navigateByUrl("/adminprofile");
        }
        else{
          console.log("Fail");
        }
       
      });

    

  }

}
