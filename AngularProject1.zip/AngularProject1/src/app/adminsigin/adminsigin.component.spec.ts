import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminsiginComponent } from './adminsigin.component';

describe('AdminsiginComponent', () => {
  let component: AdminsiginComponent;
  let fixture: ComponentFixture<AdminsiginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminsiginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminsiginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
