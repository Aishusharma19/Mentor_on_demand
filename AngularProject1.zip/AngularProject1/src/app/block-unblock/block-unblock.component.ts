import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-block-unblock',
  templateUrl: './block-unblock.component.html',
  styleUrls: ['./block-unblock.component.css']
})
export class BlockUnblockComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
