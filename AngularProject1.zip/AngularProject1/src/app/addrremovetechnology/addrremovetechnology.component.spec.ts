import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddrremovetechnologyComponent } from './addrremovetechnology.component';

describe('AddrremovetechnologyComponent', () => {
  let component: AddrremovetechnologyComponent;
  let fixture: ComponentFixture<AddrremovetechnologyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddrremovetechnologyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddrremovetechnologyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
