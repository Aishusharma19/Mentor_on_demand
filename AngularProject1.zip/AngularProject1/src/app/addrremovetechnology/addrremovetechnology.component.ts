import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addrremovetechnology',
  templateUrl: './addrremovetechnology.component.html',
  styleUrls: ['./addrremovetechnology.component.css']
})
export class AddrremovetechnologyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
