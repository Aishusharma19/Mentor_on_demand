import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unblock',
  templateUrl: './unblock.component.html',
  styleUrls: ['./unblock.component.css']
})
export class UnblockComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
