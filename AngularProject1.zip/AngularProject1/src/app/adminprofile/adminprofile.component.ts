import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { TechnologyserviceService } from '../shared/technologyservice.service';
import{Technology}from  '../shared/technology';
import { HttpClient } from '@angular/common/http';
import {HttpClientModule} from '@angular/common/http';






@Component({
  selector: 'app-adminprofile',
  templateUrl: './adminprofile.component.html',
  styleUrls: ['./adminprofile.component.css']
})
export class AdminprofileComponent implements OnInit {
technology:string;

  constructor(private route:ActivatedRoute,private router:Router,private technologyservice:TechnologyserviceService,private formBuilder:FormBuilder) { }  
  tech:Technology=new Technology();
  addtechnologyform:FormsModule;
  submitted=false;
  
  ngOnInit() {
    jQuery(document).ready(function() {
      var jQuerybtnSets = jQuery('#responsive'),
      jQuerybtnLinks = jQuerybtnSets.find('a');
   
      jQuerybtnLinks.click(function(e) {
          e.preventDefault();
          jQuery(this).siblings('a.active').removeClass("active");
          jQuery(this).addClass("active");
          var index = jQuery(this).index();
          jQuery("div.user-menu>div.user-menu-content").removeClass("active");
          jQuery("div.user-menu>div.user-menu-content").eq(index).addClass("active");
      });
  });
  
  jQuery( document ).ready(function() {
      // jQuery("[rel='tooltip']").tooltip();    
   
      jQuery('.view').hover(
          function(){
              jQuery(this).find('.caption').slideDown(250); //.fadeIn(250)
          },
          function(){
              jQuery(this).find('.caption').slideUp(250); //.fadeOut(205)
          }
      ); 
  });
  this. addtechnologyform=this.formBuilder.group(
    {
      technologyname:['',Validators.required],
     
    } );
    
  

  }
  onSubmit(){
    this.submitted=true;
    this.tech.technologyName=this.technology;
   console.log(this.technology);
    this.technologyservice.createtech(this.tech).subscribe(data=>console.log(data),error=>console.log(error));
    this.router.navigateByUrl("/addremovetechnology");
    
    
    
    
  }
  
  



}

