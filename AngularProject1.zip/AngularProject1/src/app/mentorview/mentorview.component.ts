import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';

@Component({
  selector: 'app-mentorview',
  templateUrl: './mentorview.component.html',
  styleUrls: ['./mentorview.component.css']
})
export class MentorviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    jQuery(document).ready(function() {
      var jQuerybtnSets = jQuery('#responsive'),
      jQuerybtnLinks = jQuerybtnSets.find('a');
   
      jQuerybtnLinks.click(function(e) {
          e.preventDefault();
          jQuery(this).siblings('a.active').removeClass("active");
          jQuery(this).addClass("active");
          var index = jQuery(this).index();
          jQuery("div.user-menu>div.user-menu-content").removeClass("active");
          jQuery("div.user-menu>div.user-menu-content").eq(index).addClass("active");
      });
  });
  
  jQuery( document ).ready(function() {
      // jQuery("[rel='tooltip']").tooltip();    
   
      jQuery('.view').hover(
          function(){
              jQuery(this).find('.caption').slideDown(250); //.fadeIn(250)
          },
          function(){
              jQuery(this).find('.caption').slideUp(250); //.fadeOut(205)
          }
      ); 
  });
  }

}
