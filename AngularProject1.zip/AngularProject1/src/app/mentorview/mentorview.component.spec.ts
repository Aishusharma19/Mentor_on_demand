import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MentorviewComponent } from './mentorview.component';

describe('MentorviewComponent', () => {
  let component: MentorviewComponent;
  let fixture: ComponentFixture<MentorviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MentorviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MentorviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
