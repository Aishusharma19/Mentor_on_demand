import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-newtechnology',
  templateUrl: './newtechnology.component.html',
  styleUrls: ['./newtechnology.component.css']
})
export class NewtechnologyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
