import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { MentorSignup } from '../shared/mentor-signup';
import { MentorSignupServiceService } from '../shared/mentor-signup-service.service';



@Component({
  selector: 'app-mentorsignin',
  templateUrl: './mentorsignin.component.html',
  styleUrls: ['./mentorsignin.component.css']
})
export class MentorsigninComponent implements OnInit {
  mentorSignupform:FormGroup;
  mentorSigninform:FormGroup;
  submitted=false;


  constructor(private route:ActivatedRoute,private router:Router,private mentorService:MentorSignupServiceService,private formBuilder:FormBuilder) { }
  mentorSignup:MentorSignup=new MentorSignup();
  ngOnInit() {
    this.mentorSignupform=this.formBuilder.group(
      {
        formFirstname:['',Validators.required],
        formlastname:['',Validators.required],
        formemail:['',Validators.required],
        formpassword:['',Validators.required],
      }
    );
    this.mentorSigninform=this.formBuilder.group(
      {
        formusername:['',Validators.required],
        formpassword:['',Validators.required],
       
      });

  }
  get f(){return this.mentorSignupform.controls;}
  onSubmit1(){
    this.submitted=true;
    this.mentorSignup.firstname=this.mentorSignupform.get('formFirstname').value;
    this.mentorSignup.lastname=this.mentorSignupform.get('formlastname').value;
    this.mentorSignup.email=this.mentorSignupform.get('formemail').value;
    this.mentorSignup.password=this.mentorSignupform.get('formpassword').value;
    this.mentorService.creatementor(this.mentorSignup).subscribe(data=>console.log(data),error=>console.log(error));
    this.mentorService.mentorLogin(this.mentorSigninform.get("username").value).subscribe(data=>console.log(data),error=>console.log(error));
    this.router.navigate(['/mentorprofile']);
  }
  onSubmit2(){
    this.mentorService.mentorLogin(this.mentorSigninform.get("formusername").value).subscribe(
      data =>{
        this.mentorSignup=data;
      if(this.mentorSigninform.get("formpassword").value==this.mentorSignup.password){
          console.log("Success");
          this.router.navigateByUrl("/mentorprofile");
        }
        else{
          console.log("Fail");
        }
       
      });
    }

}
