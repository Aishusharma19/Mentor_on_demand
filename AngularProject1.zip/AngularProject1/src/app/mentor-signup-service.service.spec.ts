import { TestBed } from '@angular/core/testing';

import { MentorSignupServiceService } from './mentor-signup-service.service';

describe('MentorSignupServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MentorSignupServiceService = TestBed.get(MentorSignupServiceService);
    expect(service).toBeTruthy();
  });
});
