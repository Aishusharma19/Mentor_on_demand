import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userunblock',
  templateUrl: './userunblock.component.html',
  styleUrls: ['./userunblock.component.css']
})
export class UserunblockComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
