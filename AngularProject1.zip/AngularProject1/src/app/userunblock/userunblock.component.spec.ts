import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserunblockComponent } from './userunblock.component';

describe('UserunblockComponent', () => {
  let component: UserunblockComponent;
  let fixture: ComponentFixture<UserunblockComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserunblockComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserunblockComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
