export class UserSignup {
    firstname:String;
    lastname:String;
    email:String;
    password:String
}
