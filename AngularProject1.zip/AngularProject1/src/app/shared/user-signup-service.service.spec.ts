import { TestBed } from '@angular/core/testing';

import { UserSignupServiceService } from './user-signup-service.service';

describe('UserSignupServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: UserSignupServiceService = TestBed.get(UserSignupServiceService);
    expect(service).toBeTruthy();
  });
});
