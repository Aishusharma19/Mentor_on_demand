import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { MentorSignup } from './mentor-signup';




@Injectable({
  providedIn: 'root'
})
export class MentorSignupServiceService {
  private baseurl='http://localhost:8045/';

  constructor(private http:HttpClient) { }
  creatementor(MentorSignup:object):Observable<object>{
   alert("Signed up now Signin!");
    return this.http.post(`${this.baseurl}`+'Trainer/trainer-signup',MentorSignup)

  }
  mentorLogin(user : string):Observable<MentorSignup>{
    return this.http.get<MentorSignup>('http://localhost:8045/Trainer/userName/'+user)
  }
}
