export class MentorSignup {
        firstname:String;
        lastname:String;
        email:String;
        password:String
    }

