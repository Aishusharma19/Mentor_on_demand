import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UserSignup } from './user-signup';




@Injectable({
  providedIn: 'root'
})
export class UserSignupServiceService {
  private baseurl='http://localhost:8045/';

  constructor(private http:HttpClient) { }
  createUser(UserSignup:object):Observable<object>{
    alert("Signed up..sign in!!");
    return this.http.post(`${this.baseurl}`+'trainee/trainee-signup',UserSignup)

  }
  
  userLogin(user : string):Observable<UserSignup>{
    return this.http.get<UserSignup>('http://localhost:8045/trainee/userName/'+user)
  }
}
