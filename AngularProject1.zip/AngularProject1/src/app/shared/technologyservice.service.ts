import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import{Technology} from './technology';




@Injectable({
  providedIn: 'root'
})
export class TechnologyserviceService {
  private baseurl='http://localhost:8045/';

  constructor(private http:HttpClient) { }
  createtech(Technology:object):Observable<object>{
    //alert("Signed up..sign in!!");
    return this.http.post(`${this.baseurl}`+'admin/admin/tech',Technology);

  }
  
}
