export class Technology {
    technologyName:String;
}
