import { MentorSignup } from './mentor-signup';

describe('MentorSignup', () => {
  it('should create an instance', () => {
    expect(new MentorSignup()).toBeTruthy();
  });
});
