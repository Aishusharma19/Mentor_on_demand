import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blockunblock',
  templateUrl: './blockunblock.component.html',
  styleUrls: ['./blockunblock.component.css']
})
export class BlockunblockComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
