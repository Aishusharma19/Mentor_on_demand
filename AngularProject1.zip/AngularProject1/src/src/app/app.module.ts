import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FooterComponent } from './footer/footer.component';
import { HomepageComponent } from './homepage/homepage.component';

import { MentorlistComponent } from './mentorlist/mentorlist.component';
import { MentorprofileComponent } from './mentorprofile/mentorprofile.component';
import { MentorviewComponent } from './mentorview/mentorview.component';
import { MenteeprofileComponent } from './menteeprofile/menteeprofile.component';
import { AdminprofileComponent } from './adminprofile/adminprofile.component';
import { PaymentComponent } from './payment/payment.component';
import { MentorsigninComponent } from './mentorsignin/mentorsignin.component';
import { MenteesigninComponent } from './menteesignin/menteesignin.component';
import { AdminsiginComponent } from './adminsigin/adminsigin.component';

@NgModule({
  declarations: [
    AppComponent,
    FooterComponent,
    HomepageComponent,
    
   
    MentorlistComponent,
    
   
    MentorprofileComponent,
    
   
    MentorviewComponent,
    
   
    MenteeprofileComponent,
    
   
    AdminprofileComponent,
    
   
    PaymentComponent,
    
   
    MentorsigninComponent,
    
   
    MenteesigninComponent,
    
   
    AdminsiginComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
