import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentcommissionComponent } from './paymentcommission.component';

describe('PaymentcommissionComponent', () => {
  let component: PaymentcommissionComponent;
  let fixture: ComponentFixture<PaymentcommissionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PaymentcommissionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PaymentcommissionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
