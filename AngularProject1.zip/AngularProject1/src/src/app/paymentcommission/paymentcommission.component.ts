import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paymentcommission',
  templateUrl: './paymentcommission.component.html',
  styleUrls: ['./paymentcommission.component.css']
})
export class PaymentcommissionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
