import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminsigin',
  templateUrl: './adminsigin.component.html',
  styleUrls: ['./adminsigin.component.css']
})
export class AdminsiginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
