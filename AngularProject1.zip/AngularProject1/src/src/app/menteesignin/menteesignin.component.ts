import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menteesignin',
  templateUrl: './menteesignin.component.html',
  styleUrls: ['./menteesignin.component.css']
})
export class MenteesigninComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
