import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addremovetech',
  templateUrl: './addremovetech.component.html',
  styleUrls: ['./addremovetech.component.css']
})
export class AddremovetechComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
