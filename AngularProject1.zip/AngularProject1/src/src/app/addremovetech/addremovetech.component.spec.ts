import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddremovetechComponent } from './addremovetech.component';

describe('AddremovetechComponent', () => {
  let component: AddremovetechComponent;
  let fixture: ComponentFixture<AddremovetechComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddremovetechComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddremovetechComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
