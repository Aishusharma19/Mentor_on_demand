import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentorsignin',
  templateUrl: './mentorsignin.component.html',
  styleUrls: ['./mentorsignin.component.css']
})
export class MentorsigninComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
